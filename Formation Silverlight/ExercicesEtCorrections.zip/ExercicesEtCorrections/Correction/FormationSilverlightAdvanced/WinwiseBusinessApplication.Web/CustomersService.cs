﻿
namespace WinwiseBusinessApplication.Web
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Web.Ria;
    using System.Web.Ria.Data;
    using System.Web.DomainServices;
    using System.Data;
    using System.Web.DomainServices.LinqToEntities;


    // Implements application logic using the NORTHWNDEntities context.
    // TODO: Add your application logic to these methods or in additional methods.
    [EnableClientAccess()]
    public class CustomersService : LinqToEntitiesDomainService<NORTHWNDEntities>
    {

        // TODO: Consider
        // 1. Adding parameters to this method and constraining returned results, and/or
        // 2. Adding query methods taking different parameters.
        public IQueryable<Customers> GetCustomers()
        {
            return this.Context.Customers;
        }

        public void InsertCustomers(Customers customers)
        {
            this.Context.AddToCustomers(customers);
        }

        public void UpdateCustomers(Customers currentCustomers)
        {
            this.Context.AttachAsModified(currentCustomers, this.ChangeSet.GetOriginal(currentCustomers));
        }

        public void DeleteCustomers(Customers customers)
        {
            if ((customers.EntityState == EntityState.Detached))
            {
                this.Context.Attach(customers);
            }
            this.Context.DeleteObject(customers);
        }
    }
}


