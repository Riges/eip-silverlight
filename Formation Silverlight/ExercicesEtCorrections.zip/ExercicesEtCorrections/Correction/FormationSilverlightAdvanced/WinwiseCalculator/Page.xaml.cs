﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WinwiseCalculator
{
    public partial class Page : UserControl
    {
        private string leftOperand = null;
        private string rightOperand = null;
        private bool clear = true;
        private bool endEquation = false;
        private bool operatorSelected = false;
        private string currentOperator = null;

        public Page()
        {
            InitializeComponent();
        }

        private void OnButtonOperandClick(object sender, RoutedEventArgs e)
        {
            Button operandButton = sender as Button;
            if (operandButton != null)
            {
                this.operatorSelected = false;
                if (this.clear)
                {
                    this.clear = false;
                    this.EquationTextBox.Text = operandButton.Content as string;
                }
                else
                {
                    this.EquationTextBox.Text += operandButton.Content as string;
                }
            }
        }

        private void OnButtonOperatorClick(object sender, RoutedEventArgs e)
        {
            Button operatorButton = sender as Button;
            if (operatorButton != null && !this.operatorSelected)
            {
                this.operatorSelected = true;
                if (this.currentOperator == null)
                {
                    if (this.leftOperand == null)
                    {
                        this.leftOperand = this.EquationTextBox.Text;
                    }
                    else
                    {
                        this.rightOperand = this.EquationTextBox.Text;
                    }
                }
                else
                {
                    this.Result();
                }
                this.currentOperator = operatorButton.Content as string;
                this.clear = true;
            }
        }

        private void OnButtonResultClick(object sender, RoutedEventArgs e)
        {
            this.endEquation = true;
            this.Result();
        }

        private void Result()
        {
            if (this.currentOperator == null || this.leftOperand == null)
            {
                return;
            }

            try
            {
                this.rightOperand = this.EquationTextBox.Text;
                int result = ComputeResult(this.leftOperand, this.rightOperand, this.currentOperator[0]);
                this.EquationTextBox.Text = result.ToString();
                this.leftOperand = this.endEquation ? null : result.ToString();
                this.rightOperand = null;
                this.currentOperator = null;
                this.clear = true;
                this.endEquation = false;
            }
            catch (Exception exception)
            {
                this.EquationTextBox.Text = exception.Message;
            }
        }

        internal static int ComputeResult(string str1, string str2, char op)
        {
            int nb1;
            int nb2;

            if (!int.TryParse(str1, out nb1))
            {
                throw new InvalidIntegerException(str1 + " is not a valid integer");
            }

            if (!int.TryParse(str2, out nb2))
            {
                throw new InvalidIntegerException(str2 + " is not a valid integer");
            }

            switch (op)
            {
                case '*':
                    return nb1 * nb2;
                case '/':
                    return nb1 / nb2;
                case '+':
                    return nb1 + nb2;
                case '-':
                    return nb1 - nb2;
                default:
                    return 0;
            }
        }
    }
}
