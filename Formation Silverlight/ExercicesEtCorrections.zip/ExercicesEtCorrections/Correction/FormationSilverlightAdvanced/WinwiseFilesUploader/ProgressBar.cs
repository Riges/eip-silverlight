﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WinwiseFilesUploader
{
    [TemplatePart(Name = ProgressBar.RootElement, Type = typeof(FrameworkElement))]
    [TemplatePart(Name = ProgressBar.ProgressIndicatorElement, Type = typeof(FrameworkElement))]
    [TemplatePart(Name = ProgressBar.ProgressValueElement, Type = typeof(TextBlock))]
    public class ProgressBar : Control
    {
        #region Member Fields

        private const string RootElement = "Root";
        private const string ProgressIndicatorElement = "ProgressIndicator";
        private const string ProgressValueElement = "ProgressValue";

        protected FrameworkElement Root;
        protected FrameworkElement ProgressIndicator;
        protected TextBlock ProgressValue;

        #endregion

        public ProgressBar() : base()
        {
            DefaultStyleKey = typeof (ProgressBar);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            this.Root = this.GetTemplateChild(RootElement) as FrameworkElement;
            this.ProgressIndicator = this.GetTemplateChild(ProgressIndicatorElement) as FrameworkElement;
            this.ProgressValue = this.GetTemplateChild(ProgressValueElement) as TextBlock;
        }

        #region Percentage

        /// <summary>
        /// Identifies the Percentage dependency property.
        /// </summary>
        public static readonly DependencyProperty PercentageProperty = DependencyProperty.Register("Percentage", typeof(int), typeof(ProgressBar), null);

        /// <summary>
        /// Gets or sets the Percentage possible Value of the int object.
        /// </summary>
        public int Percentage
        {
            get { return (int)GetValue(PercentageProperty); }
            set 
            { 
                SetValue(PercentageProperty, value);
                this.ProgressValue.Text = value.ToString() + "%";
                this.ProgressIndicator.Width = value * 0.01 * this.Root.Width;
            }
        }

        #endregion Percentage                
    }
}
