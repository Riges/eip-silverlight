﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;

namespace WinwiseFilesUploader
{
    public partial class Page : UserControl
    {
        #region Member Fields
        private const string PASSWORD = "W!inw$e@2009";
        private byte[] key;
        private byte[] FileContent;
        private UploadService.UploadClient uploadClient;
        private Dictionary<string, byte[]> listOfFile = new Dictionary<string, byte[]>();
        private System.ComponentModel.BackgroundWorker worker;
        private System.IO.IsolatedStorage.IsolatedStorageSettings appSettings = System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings;

        #endregion

        public Page()
        {
            InitializeComponent();
            
            this.key = SecurityHelper.GetHashKey(PASSWORD);

            this.btnBrowse.Click += new RoutedEventHandler(btnBrowse_Click);
            this.btnUpload.Click += new RoutedEventHandler(btnUpload_Click);

            uploadClient = new WinwiseFilesUploader.UploadService.UploadClient();
            uploadClient.StoreFileCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(uploadClient_StoreFileCompleted);

            //ResetIsolatedStorageFile();

            InitializeIsolatedStorage();
        }

        private void ResetIsolatedStorageFile()
        {
            appSettings["HistoryFileContent"] = string.Empty;
        }

        private void InitializeIsolatedStorage()
        {
            if (!appSettings.Contains("HistoryFileContent"))
            {
                appSettings.Add("HistoryFileContent", string.Empty);
            }

            ParseIsolatedStorageFile(SecurityHelper.Decrypt(this.key, Convert.ToString(appSettings["HistoryFileContent"])));
        }

        private void ParseIsolatedStorageFile(string fileContent)
        {
            this.lbFilesUploaded.ItemsSource = null;

            var results = from file in fileContent.Split(';')
                          select file;

            if (results.Count() > 0)
            {
                this.lbFilesUploaded.ItemsSource = results.TakeWhile(s => !string.IsNullOrEmpty(s));
            }
        }

        #region Methods used to choose a file and upload it

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Fichiers Texte|*.txt";

            #region Multiple Uploads

            //ofd.EnableMultipleSelection = true;
            ofd.Multiselect = true;

            if (ofd.ShowDialog().Value)
            {
                foreach (var item in ofd.Files)
                {
                    using (Stream streamFileToUpload = item.OpenRead())
                    {
                        FileContent = new byte[streamFileToUpload.Length];
                        streamFileToUpload.Read(FileContent, 0, (int)streamFileToUpload.Length);

                        listOfFile.Add(item.Name, FileContent);
                    }
                }

                this.tbFileToUpload.Text = listOfFile.Keys.ToList()[0];
                this.tbFileToUpload2.Text = listOfFile.Keys.ToList()[1];
                this.tbFileToUpload3.Text = listOfFile.Keys.ToList()[2];
            }

            #endregion

            #region Single Upload

            //ofd.EnableMultipleSelection = false;            

            //if (ofd.ShowDialog() == DialogResult.OK)
            //{
            //    this.tbFileToUpload.Text = ofd.File.Name;

            //    using (Stream streamFileToUpload = ofd.SelectedFile.OpenRead())
            //    {
            //        FileContent = new byte[streamFileToUpload.Length];
            //        streamFileToUpload.Read(FileContent, 0, (int)streamFileToUpload.Length);
            //    }
            //}

            #endregion
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            #region Single Upload

            //UploadService.FileUpload fileUpload = new WinwiseFilesUploader.UploadService.FileUpload();
            
            //fileUpload.Name = this.tbFileToUpload.Text;
            //fileUpload.File = FileContent;

            //uploadClient.StoreFileCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(uploadClient_StoreFileCompleted);
            //uploadClient.StoreFileAsync(fileUpload);

            #endregion

            #region Multiple Uploads

            worker = new System.ComponentModel.BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(worker_ProgressChanged);
            worker.DoWork += new System.ComponentModel.DoWorkEventHandler(worker_DoWork);
            worker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);

            worker.RunWorkerAsync();

            #endregion
        }

        #endregion

        #region Methods used by the BackgroundWorker

        private void worker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            for(int i = 0; i <= listOfFile.Count - 1; i++)
            {
                KeyValuePair<string, byte[]> item = listOfFile.ElementAt(i);

                UploadService.FileUpload fileUpload = new WinwiseFilesUploader.UploadService.FileUpload();

                fileUpload.Name = item.Key;
                fileUpload.File = item.Value;

                this.Dispatcher.BeginInvoke(() => uploadClient.StoreFileAsync(fileUpload, string.Concat(i, ";", fileUpload.Name)));

                worker.ReportProgress((i + 1) * Convert.ToInt32(100 / listOfFile.Count));

                // Pause pour voir l'avancement
                if (i != listOfFile.Count)
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
        }

        private void worker_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            this.pb.Percentage = e.ProgressPercentage;
        }

        private void worker_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            if (e.Error == null && !e.Cancelled && (this.pb.Percentage != 100))
            {
                this.pb.Percentage = 100;

                ParseIsolatedStorageFile(SecurityHelper.Decrypt(this.key, Convert.ToString(appSettings["HistoryFileContent"])));
            }
        }

        #endregion

        private void uploadClient_StoreFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            #region Single Upload

            //if (e.Error == null)
            //{
            //    string contentFile = SecurityHelper.Decrypt(this.key, Convert.ToString(appSettings["HistoryFileContent"]));
            //    contentFile += string.Concat(this.tbFileToUpload.Text, ";");

            //    appSettings["HistoryFileContent"] = SecurityHelper.Encrypt(this.key, contentFile);

            //    ParseIsolatedStorageFile(SecurityHelper.Decrypt(this.key, Convert.ToString(appSettings["HistoryFileContent"])));

            //    this.tbFileToUpload.Text = "Fichier uploadé !";
            //}
            //else
            //{
            //    this.tbFileToUpload.Text = string.Format("Une erreur est survenue: {0}", e.Error.Message);
            //}

            #endregion

            #region Multiples Upload
            var parameters = Convert.ToString(e.UserState).Split(';');

            int i = Convert.ToInt32(parameters[0]);

            if (e.Error == null)
            {
                string contentFile = SecurityHelper.Decrypt(this.key, Convert.ToString(appSettings["HistoryFileContent"]));
                contentFile += string.Concat(Convert.ToString(parameters[1]), ";");
                appSettings["HistoryFileContent"] = SecurityHelper.Encrypt(this.key, contentFile);

                if (i == 0)
                {
                    this.tbFileToUpload.Text = "Fichier uploadé !";
                }
                else if (i == 1)
                {
                    this.tbFileToUpload2.Text = "Fichier uploadé !";
                }
                else if (i == 2)
                {
                    this.tbFileToUpload3.Text = "Fichier uploadé !";
                }
            }
            else
            {
                string errorMsg = string.Format("Une erreur est survenue: {0}", e.Error.Message);

                if (i == 0)
                {
                    this.tbFileToUpload.Text = errorMsg;
                }
                else if (i == 1)
                {
                    this.tbFileToUpload2.Text = errorMsg;
                }
                else if (i == 2)
                {
                    this.tbFileToUpload3.Text = errorMsg;
                }
            }
            #endregion
        }
    }
}
