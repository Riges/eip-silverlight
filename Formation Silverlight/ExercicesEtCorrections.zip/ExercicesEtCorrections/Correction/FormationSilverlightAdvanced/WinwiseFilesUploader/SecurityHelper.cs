﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace WinwiseFilesUploader
{
    internal static class SecurityHelper
    {
        internal static byte[] GetHashKey(string password)
        {
            return new Rfc2898DeriveBytes(password, UTF8Encoding.UTF8.GetBytes("Some salt")).GetBytes(16);
        }

        internal static string Encrypt(byte[] key, string dataToEncrypt)
        {
            AesManaged encryptor = new AesManaged
            {
                Key = key,
                IV = key
            };
            using (MemoryStream encryptionStream = new MemoryStream())
            {
                using (CryptoStream encrypt = new CryptoStream(encryptionStream, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    byte[] utfD1 = UTF8Encoding.UTF8.GetBytes(dataToEncrypt);
                    encrypt.Write(utfD1, 0, utfD1.Length);
                    encrypt.FlushFinalBlock();
                    encrypt.Close();
                    return Convert.ToBase64String(encryptionStream.ToArray());
                }
            }
        }

        internal static string Decrypt(byte[] key, string encryptedString)
        {
            if (String.IsNullOrEmpty(encryptedString))
                return String.Empty;
            AesManaged decryptor = new AesManaged
            {
                Key = key,
                IV = key
            };
            byte[] encryptedData = Convert.FromBase64String(encryptedString);
            using (MemoryStream decryptionStream = new MemoryStream())
            {
                using (CryptoStream decrypt = new CryptoStream(decryptionStream, decryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    decrypt.Write(encryptedData, 0, encryptedData.Length);
                    decrypt.Flush();
                    decrypt.Close();
                    byte[] decryptedData = decryptionStream.ToArray();
                    return UTF8Encoding.UTF8.GetString(decryptedData, 0, decryptedData.Length);
                }
            }
        }
    }
}
