﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;

namespace WinwiseDeepZoomViewer
{
    public partial class Page : UserControl
    {
        #region Member Fields

        private bool dragInProgress = false;
        private Point dragOffset;
        private Point currentPosition;

        #endregion

        public Page()
        {
            InitializeComponent();

            HtmlPage.RegisterScriptableObject("WWDZClient", this);
        }

        #region MultiScaleImage Methods

        private void MultiScaleImage_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            dragInProgress = false;
            dragOffset = new Point();
            currentPosition = new Point();
        }

        private void MultiScaleImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            dragInProgress = true;
            dragOffset = e.GetPosition(this);
            currentPosition = deepZoomObject.ViewportOrigin;
        }

        private void MultiScaleImage_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragInProgress)
            {
                Point newOrigin = new Point();
                
                newOrigin.X = currentPosition.X - (((e.GetPosition(deepZoomObject).X - dragOffset.X) / deepZoomObject.ActualWidth) * deepZoomObject.ViewportWidth);
                newOrigin.Y = currentPosition.Y - (((e.GetPosition(deepZoomObject).Y - dragOffset.Y) / deepZoomObject.ActualHeight) * deepZoomObject.ViewportWidth);

                deepZoomObject.ViewportOrigin = newOrigin;
            }
        }

        #endregion

        [ScriptableMember]
        public void DeepZoom_MouseWheel(double x, double y, int delta)
        {
            double dZoomFactor = 1.33;
            
            if (delta < 0)
            {
                dZoomFactor = 1 / 1.33;
            }

            Point pz = deepZoomObject.ElementToLogicalPoint(new Point(x, y));
            deepZoomObject.ZoomAboutLogicalPoint(dZoomFactor, pz.X, pz.Y);
        }
    }
}
