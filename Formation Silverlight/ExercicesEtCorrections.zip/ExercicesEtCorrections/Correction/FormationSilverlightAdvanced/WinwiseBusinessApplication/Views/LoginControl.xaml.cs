﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Ria.ApplicationServices;

namespace WinwiseBusinessApplication
{
    public partial class LoginControl : UserControl
    {
        private AuthenticationService _authService = RiaContext.Current.Authentication;

        public LoginControl()
        {

            InitializeComponent();

            _authService.LoggedIn += Authentication_LoggedIn;
            _authService.LoggedOut += Authentication_LoggedOut;
            UpdateLoginState();

        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            new LoginWindow().Show();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            _authService.Logout();
        }

        private void Authentication_LoggedIn(object sender, AuthenticationEventArgs e)
        {
            UpdateLoginState();
        }

        private void Authentication_LoggedOut(object sender, AuthenticationEventArgs e)
        {
            UpdateLoginState();
        }


        private void UpdateLoginState()
        {

            if (RiaContext.Current.User.AuthenticationType == "Windows")
            {
                VisualStateManager.GoToState(this, "windowsAuth", true);
            }
            else //User.AuthenticationType == "Forms"
            {
                VisualStateManager.GoToState(this, RiaContext.Current.User.IsAuthenticated ? "loggedIn" : "loggedOut", true);
            }
        }

    }
}
