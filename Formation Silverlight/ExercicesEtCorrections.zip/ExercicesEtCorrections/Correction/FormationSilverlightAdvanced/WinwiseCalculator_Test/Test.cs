﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WinwiseCalculator;

namespace WinwiseCalculator_Test
{
    [TestClass]
    public class Test : SilverlightTest
    {
        private Page page;

        [TestInitialize]
        public void Setup()
        {
            page = new Page();
            TestPanel.Children.Add(page);
        }

        [TestMethod]
        [Asynchronous]
        public void ClickButtonTest()
        {
            ButtonAutomationPeer buttonPeer = new ButtonAutomationPeer(page.Button1);
            IInvokeProvider buttonProvider = (IInvokeProvider)buttonPeer;

            EnqueueCallback(() => buttonProvider.Invoke());
            EnqueueDelay(2000);
            EnqueueCallback(() => Assert.AreEqual("1", page.EquationTextBox.Text));

            EnqueueTestComplete();
        }

        [TestMethod]
        public void TestAddition()
        {
            Assert.AreEqual(5, Page.ComputeResult("2", "3", '+'));
            Assert.AreEqual(2, Page.ComputeResult("2", "0", '+'));
            Assert.AreEqual(-1, Page.ComputeResult("5", "-6", '+'));
        }

        [TestMethod]
        public void TestSubstraction()
        {
            Assert.AreEqual(8, Page.ComputeResult("10", "2", '-'));
            Assert.AreEqual(5, Page.ComputeResult("5", "0", '-'));
            Assert.AreEqual(3, Page.ComputeResult("2", "-1", '-'));
        }

        [TestMethod]
        public void TestMultiplication()
        {
            Assert.AreEqual(12, Page.ComputeResult("3", "4", '*'));
            Assert.AreEqual(3, Page.ComputeResult("3", "1", '*'));
            Assert.AreEqual(0, Page.ComputeResult("5", "0", '*'));
            Assert.AreEqual(8, Page.ComputeResult("-2", "-4", '*'));
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidIntegerException))]
        public void TestValidInteger()
        {
            Page.ComputeResult("999999999999999", "9999999999999999999", '*');
            Page.ComputeResult("hello", "world", '+');
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void TestDivision()
        {
            Assert.AreEqual(4, Page.ComputeResult("8", "2", '/'));
            Assert.AreEqual(6, Page.ComputeResult("6", "1", '/'));
            Assert.AreEqual(3, Page.ComputeResult("-6", "-2", '/'));
            Page.ComputeResult("3", "0", '/');
        }
    }
}