﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Net;
using WinwiseMediaLibrary;

namespace WinwiseMediaPlayer
{
    public partial class Page : UserControl
    {
        #region Member Fields

        private System.Windows.Threading.DispatcherTimer timer;

        #endregion

        public Page()
        {
            InitializeComponent();

            this.Loaded += OnPageLoaded;
        }

        void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            this.media.MarkerReached += new TimelineMarkerRoutedEventHandler(media_MarkerReached);
            this.media.MediaOpened += new RoutedEventHandler(media_MediaOpened);
            this.media.Source = new Uri("http://localhost:55555/Videos/HaloWithoutSubtitles.wmv", UriKind.Absolute);

            timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 0, 0, 1);
            timer.Tick += (s, args) => this.tb.Text = this.media.Position.ToString();

            //timer.Start();
        }

        private void media_MediaOpened(object sender, RoutedEventArgs e)
        {
            var srtParser = new SrtParser(new Uri("http://localhost:55555/SubTitles/SousTitresVideoHalo.srt", UriKind.Absolute));
            srtParser.Loaded +=
                        (s, a) =>
                        {
                            foreach (var marker in srtParser.GetMarkers())
                                media.Markers.Add(marker);
                        };
            srtParser.Load();

        }

        private void media_MarkerReached(object sender, TimelineMarkerRoutedEventArgs e)
        {
            if (e.Marker != null)
            {
                //if (!string.IsNullOrEmpty(e.Marker.Text))
                {
                    this.tbSubtitle.Text = e.Marker.Text;
                }
            }
        }

        #region Methods used by the MediaElement

        private void btPlay_Click(object sender, RoutedEventArgs e)
        {
            this.media.Play();

            if (timer != null)
            {
                timer.Start();
            }
        }

        private void btPause_Click(object sender, RoutedEventArgs e)
        {
            this.media.Pause();
        }

        private void btStop_Click(object sender, RoutedEventArgs e)
        {
            this.media.Stop();

            if (timer != null)
            {
                timer.Stop();

                this.tb.Text = this.media.Position.ToString();
            }
        }

        #endregion
    }
}
