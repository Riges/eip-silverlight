﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace WinwiseBrowserNavigation.Views
{
    public partial class UserList : Page
    {
        public UserList()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(UserList_Loaded);
        }

        private void UserList_Loaded(object sender, RoutedEventArgs e)
        {
            this.ListBox.DataContext = Models.Users.GetUsers();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Models.User selectedUser = ((ListBox)sender).SelectedItem as Models.User;
            this.NavigationService.Navigate(new Uri(String.Format("/User/{0}", selectedUser.Id), UriKind.Relative));
        }
    }
}
