﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;

namespace WinwiseBrowserNavigation.Models
{
    public static class Users
    {
        private static List<User> s_users =
            new List<User>
            {
                new User { Id = 0, Age = 29, FirstName = "Davy", LastName = "Frontigny" },
                new User { Id = 1, Age = 26, FirstName = "Thomas", LastName = "Lebrun" },
                new User { Id = 2, Age = 25, FirstName = "Simon", LastName = "Ferquel" }
            };

        public static List<User> GetUsers()
        {
            return s_users;
        }

        public static User GetUser(int id)
        {
            return s_users.FirstOrDefault(user => user.Id == id);
        }
    }

    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
    }
}
