﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
using System.Windows.Automation;

namespace WinwiseTemplatableControl
{
    [TemplatePart(Name = WinwiseExpanderPanel.RootElement, Type = typeof(FrameworkElement))]
    [TemplatePart(Name = WinwiseExpanderPanel.HeaderElement, Type = typeof(ContentControl))]
    [TemplatePart(Name = WinwiseExpanderPanel.ContentElement, Type = typeof(ContentControl))]
    [TemplatePart(Name = WinwiseExpanderPanel.ButtonElement, Type = typeof(ToggleButton))]
    [TemplateVisualStateAttribute(Name = WinwiseExpanderPanel.Opened, GroupName = "CommonStates")]
    [TemplateVisualStateAttribute(Name = WinwiseExpanderPanel.Closed, GroupName = "CommonStates")]
    public class WinwiseExpanderPanel : ContentControl
    {
        #region Constants

        private const string RootElement = "RootElement";
        private const string HeaderElement = "HeaderElement";
        private const string ContentElement = "ContentElement";
        private const string ButtonElement = "ButtonElement";
        private const string Opened = "Opened";
        private const string Closed = "Closed";

        #endregion

        #region Member Fields

        FrameworkElement mRootElement = null;
        ToggleButton mButtonElement = null;

        #endregion

        #region Properties

        public object Header
        {
            get { return (object)GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        public static readonly DependencyProperty HeaderProperty =
            DependencyProperty.Register("Header", typeof(object), typeof(WinwiseExpanderPanel), null);

        public static readonly DependencyProperty IsOpenedProperty =
            DependencyProperty.Register("IsOpened", typeof(bool), typeof(WinwiseExpanderPanel), new PropertyMetadata(new PropertyChangedCallback(OnIsOpenedPropertyChanged)));

        public bool IsOpened
        {
            get
            {
                if (mButtonElement != null)
                {
                    return mButtonElement.IsChecked ?? false;
                }
                else
                {
                    return (bool)GetValue(IsOpenedProperty);
                }
            }
            set
            {
                if (mButtonElement != null)
                {
                    mButtonElement.IsChecked = value;
                }
                else
                {
                    SetValue(IsOpenedProperty, value);
                }

                ChangeState();
            }
        }

        private static void OnIsOpenedPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs args)
        {
            ((WinwiseExpanderPanel)sender).IsOpened = (bool)args.NewValue;
        }


        #endregion

        #region Private Methods

        private void ChangeState()
        {
            if (IsOpened)
            {
                VisualStateManager.GoToState(this, WinwiseExpanderPanel.Opened, true);
            }
            else
            {
                VisualStateManager.GoToState(this, WinwiseExpanderPanel.Closed, true);
            }
        }

        private void mButtonElement_Click(object sender, RoutedEventArgs e)
        {
            IsOpened = mButtonElement.IsChecked.Value;
        }

        public WinwiseExpanderPanel()
            : base()
        {
            DefaultStyleKey = typeof(WinwiseExpanderPanel);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            mRootElement = this.GetTemplateChild(WinwiseExpanderPanel.RootElement) as FrameworkElement;

            if (mRootElement != null)
            {
                mButtonElement = this.GetTemplateChild(WinwiseExpanderPanel.ButtonElement) as ToggleButton;
                if (mButtonElement != null)
                {
                    mButtonElement.IsChecked = IsOpened;
                    mButtonElement.Click += new RoutedEventHandler(mButtonElement_Click);
                }
            }

            ChangeState();
        }

        #endregion

        #region UI Automation
        protected override AutomationPeer OnCreateAutomationPeer()
        {
            return new WinwiseExpanderPanelAutomationPeer(this);
        }

        public class WinwiseExpanderPanelAutomationPeer : FrameworkElementAutomationPeer, IToggleProvider
        {
            private WinwiseExpanderPanel m_WinwiseExpanderPanel;

            public WinwiseExpanderPanelAutomationPeer(WinwiseExpanderPanel winwiseExpanderPanel) : base(winwiseExpanderPanel)
            {
                this.m_WinwiseExpanderPanel = winwiseExpanderPanel;
            }    

            protected override string GetClassNameCore()
            {
                return "WinwiseExpanderPanel";
            }

            protected override AutomationControlType GetAutomationControlTypeCore()
            {
                return AutomationControlType.Pane;
            }

            public override object GetPattern(PatternInterface patternInterface)
            {
                if (patternInterface == PatternInterface.Toggle)
                {
                    return this;
                }
                return base.GetPattern(patternInterface);
            }

            protected override bool IsContentElementCore()
            {
                return true;
            }

            #region IToggleProvider Members
            public void Toggle()
            {
                this.m_WinwiseExpanderPanel.IsOpened = !this.m_WinwiseExpanderPanel.IsOpened;
            }

            public ToggleState ToggleState
            {
                get
                {
                    return m_WinwiseExpanderPanel.IsOpened ? ToggleState.On : ToggleState.Off;
                }
            }
            #endregion
        }
        #endregion
    }
}
