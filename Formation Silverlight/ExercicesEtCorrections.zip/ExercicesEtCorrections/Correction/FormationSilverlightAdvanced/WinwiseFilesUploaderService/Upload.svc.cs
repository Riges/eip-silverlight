﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using System.IO;
using System.Configuration;
using System.Web;

namespace WinwiseFilesUploaderService
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class Upload : IUpload
    {
        public void StoreFile(FileUpload UploadedFile)
        {
            FileStream FileStream = new FileStream(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["FileUploadLocation"]) + UploadedFile.Name, FileMode.Create);
            FileStream.Write(UploadedFile.File, 0, UploadedFile.File.Length);

            FileStream.Close();
            FileStream.Dispose();
        }
    }
}