﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WinwiseFilesUploaderService
{
    [ServiceContract]
    public interface IUpload
    {
        [OperationContract]
        void StoreFile(FileUpload UploadedFile);
    }

    [DataContract]
    public class FileUpload
    {
        [DataMember]
        public string Name;

        [DataMember]
        public byte[] File;
    }
}
