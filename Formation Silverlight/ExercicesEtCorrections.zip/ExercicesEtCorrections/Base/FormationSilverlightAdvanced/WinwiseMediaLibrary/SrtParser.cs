﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;

namespace WinwiseMediaLibrary
{
    public class SrtParser : INotifyPropertyChanged
    {
        private bool _loaded;
        public bool IsLoaded
        {
            get { return _loaded; }
            set
            {
                if (value == _loaded)
                    return;
                _loaded = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsLoaded"));
            }
        }
        private string _srtContent;
        private Uri _srtSource;

        public SrtParser(Uri srtSource)
        {
            _srtSource = srtSource;
        }
        public void Load()
        {
            
            var client = new WebClient();
            client.DownloadStringCompleted +=
                (sender, args) =>
                {
                    if (args.Error != null)
                    {
                        if(Error != null)
                            Error(this, new ExceptionEventArgs(args.Error));
                    }
                    else
                    {
                        _srtContent = args.Result;
                        IsLoaded = true;
                        if(Loaded != null)
                            Loaded(this, EventArgs.Empty);
                    }
                };
            client.DownloadStringAsync(_srtSource);
        }

        public IEnumerable<TimelineMarker> GetMarkers()
        {
            if (!_loaded)
                throw new InvalidOperationException("SRT file not loaded");

            var results = from block in _srtContent.Split(new string[] { "\r\n\r\n" }, StringSplitOptions.RemoveEmptyEntries)
                          let lines = block.Split(new string[] { "\r\n" }, StringSplitOptions.None)
                          let timersLine = lines[1]
                          let textLine = string.Join("\r\n", lines, 2, lines.Length - 2)
                          let timerParts = timersLine.Split(new string[]{" --> "}, StringSplitOptions.None)
                          select new {Text = textLine, Start = ParseTimeSpan(timerParts[0]), End = ParseTimeSpan(timerParts[1])};
            foreach(var r in results)
            {
                yield return new TimelineMarker{ Text = r.Text, Time = r.Start, Type=string.Empty};
                yield return new TimelineMarker{ Text = string.Empty, Time = r.End, Type=string.Empty};
            }
        }

        TimeSpan ParseTimeSpan(string text)
        {
            text = text.Replace(',', '.');
            return TimeSpan.Parse(text);
        }

        public event EventHandler Loaded;
        public event EventHandler<ExceptionEventArgs> Error;

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

    public class ExceptionEventArgs : EventArgs
    {
        public ExceptionEventArgs(Exception ex)
        {
            Exception = ex;
        }
        public Exception Exception { get; private set; }
    }
}
