﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using WinwiseMediaLibrary;

namespace WinwiseMediaPlayer
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();

            this.Loaded += OnPageLoaded;
        }

        void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            this.media.Source = new Uri("http://localhost:55555/Videos/HaloWithSubtitles.wmv", UriKind.Absolute);
        }
    }
}
